To open the website:

1.Open folder in VS Code or any code editor
2.Open/navigate to terminal in code editor
3.Type: "npm start" in terminal and wait till Connected to Databse appears
4.Open any browser
5.Navigate to: "http://localhost:3000/" & the Homepage should open